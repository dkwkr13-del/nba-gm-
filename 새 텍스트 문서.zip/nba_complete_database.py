#!/usr/bin/env python3
"""
NBA Complete Database - 30 Teams, 450 Players
Source: roster.txt (October 2024)
"""

import json
import csv
from io import StringIO

# Load from the complete JSON file
with open('/home/claude/nba_complete_data.json', 'r') as f:
    ALL_NBA_TEAMS = json.load(f)

# Team abbreviation mapping
TEAM_ABBR = {
    'Boston Celtics': 'BOS', 'New York Knicks': 'NYK', 'Philadelphia 76ers': 'PHI',
    'Brooklyn Nets': 'BKN', 'Milwaukee Bucks': 'MIL', 'Cleveland Cavaliers': 'CLE',
    'Indiana Pacers': 'IND', 'Chicago Bulls': 'CHI', 'Detroit Pistons': 'DET',
    'Miami Heat': 'MIA', 'Orlando Magic': 'ORL', 'Atlanta Hawks': 'ATL',
    'Toronto Raptors': 'TOR', 'Charlotte Hornets': 'CHA', 'Washington Wizards': 'WAS',
    'Denver Nuggets': 'DEN', 'Oklahoma City Thunder': 'OKC', 'Minnesota Timberwolves': 'MIN',
    'Portland Trail Blazers': 'POR', 'Utah Jazz': 'UTA', 'Golden State Warriors': 'GSW',
    'LA Clippers': 'LAC', 'LA Lakers': 'LAL', 'Phoenix Suns': 'PHX',
    'Sacramento Kings': 'SAC', 'Dallas Mavericks': 'DAL', 'Houston Rockets': 'HOU',
    'Memphis Grizzlies': 'MEM', 'New Orleans Pelicans': 'NOP', 'San Antonio Spurs': 'SAS'
}

# Reverse mapping
ABBR_TO_TEAM = {v: k for k, v in TEAM_ABBR.items()}

def get_team_finances():
    """Get all team financial data"""
    finances = {}
    for team_name, data in ALL_NBA_TEAMS.items():
        abbr = TEAM_ABBR[team_name]
        salary = data['Salary_24_25_M']
        
        # Determine apron status based on 2024-25 thresholds
        if salary >= 188.931:
            status = 'second_apron'
        elif salary >= 178.132:
            status = 'first_apron'
        elif salary >= 170.814:
            status = 'over_tax'
        elif salary >= 140.588:
            status = 'under_tax'
        else:
            status = 'under_cap'
        
        # Calculate tax
        if salary >= 170.814:
            tax = round(salary - 170.814, 1)
        else:
            tax = 0
        
        # Flexibility
        if status == 'second_apron':
            flex = 'none'
        elif status == 'first_apron':
            flex = 'very_limited'
        elif salary > 165:
            flex = 'limited'
        elif salary > 150:
            flex = 'moderate'
        else:
            flex = 'high'
        
        finances[abbr] = {
            'full_name': team_name,
            'salary': salary,
            'apron_status': status,
            'tax_bill': tax,
            'flexibility': flex
        }
    
    return finances

def get_all_players():
    """Get all players across the league"""
    players = []
    for team_name, data in ALL_NBA_TEAMS.items():
        abbr = TEAM_ABBR[team_name]
        for player in data['Roster']:
            # Format: [Name, OVR, Salary, Age, Pos, Years]
            players.append({
                'team': abbr,
                'name': player[0],
                'ovr': player[1],
                'salary': player[2],
                'age': player[3],
                'position': player[4],
                'years_left': player[5],
                'trade_status': 'available',  # Default
                'injury_status': 'healthy'     # Default
            })
    return players

def get_team_roster(team_abbr):
    """Get roster for a specific team"""
    team_name = ABBR_TO_TEAM.get(team_abbr)
    if not team_name or team_name not in ALL_NBA_TEAMS:
        return []
    
    roster = []
    for player in ALL_NBA_TEAMS[team_name]['Roster']:
        roster.append({
            'name': player[0],
            'ovr': player[1],
            'salary': player[2],
            'age': player[3],
            'position': player[4],
            'years_left': player[5]
        })
    return roster

def get_team_picks(team_abbr):
    """Get draft picks for a team"""
    team_name = ABBR_TO_TEAM.get(team_abbr)
    if not team_name or team_name not in ALL_NBA_TEAMS:
        return {'1st': [], '2nd': []}
    
    return ALL_NBA_TEAMS[team_name]['Picks']

def get_player_by_name(player_name):
    """Find a player by name across all teams"""
    for team_name, data in ALL_NBA_TEAMS.items():
        for player in data['Roster']:
            if player[0].lower() == player_name.lower():
                return {
                    'team': TEAM_ABBR[team_name],
                    'name': player[0],
                    'ovr': player[1],
                    'salary': player[2],
                    'age': player[3],
                    'position': player[4],
                    'years_left': player[5]
                }
    return None

def print_database_stats():
    """Print comprehensive database statistics"""
    print("=" * 70)
    print("NBA COMPLETE DATABASE STATISTICS")
    print("=" * 70)
    
    total_teams = len(ALL_NBA_TEAMS)
    total_players = sum(len(t['Roster']) for t in ALL_NBA_TEAMS.values())
    total_salary = sum(t['Salary_24_25_M'] for t in ALL_NBA_TEAMS.values())
    
    print(f"\n📊 League Overview:")
    print(f"  Teams: {total_teams}")
    print(f"  Players: {total_players}")
    print(f"  Combined Salary: ${total_salary:.1f}M")
    print(f"  Average Team Salary: ${total_salary/total_teams:.1f}M")
    
    # Apron status breakdown
    finances = get_team_finances()
    second_apron = sum(1 for f in finances.values() if f['apron_status'] == 'second_apron')
    first_apron = sum(1 for f in finances.values() if f['apron_status'] == 'first_apron')
    over_tax = sum(1 for f in finances.values() if f['apron_status'] == 'over_tax')
    under_tax = sum(1 for f in finances.values() if f['apron_status'] == 'under_tax')
    under_cap = sum(1 for f in finances.values() if f['apron_status'] == 'under_cap')
    
    print(f"\n💰 Apron Status:")
    print(f"  2nd Apron: {second_apron} teams")
    print(f"  1st Apron: {first_apron} teams")
    print(f"  Over Tax: {over_tax} teams")
    print(f"  Under Tax: {under_tax} teams")
    print(f"  Under Cap: {under_cap} teams")
    
    # Top salaries
    print(f"\n💸 Top 5 Team Salaries:")
    sorted_teams = sorted(finances.items(), key=lambda x: x[1]['salary'], reverse=True)
    for i, (abbr, data) in enumerate(sorted_teams[:5], 1):
        print(f"  {i}. {abbr} (${data['salary']:.1f}M) - {data['apron_status']}")
    
    # Draft pick rich teams
    print(f"\n🎯 Draft Pick Wealthy Teams (1st rounders 2025-2029):")
    pick_counts = []
    for team_name, data in ALL_NBA_TEAMS.items():
        picks_25_29 = [p for p in data['Picks']['1st'] if any(str(y) in p for y in ['25', '26', '27', '28', '29'])]
        if len(picks_25_29) >= 8:
            pick_counts.append((TEAM_ABBR[team_name], len(picks_25_29)))
    
    for abbr, count in sorted(pick_counts, key=lambda x: x[1], reverse=True)[:5]:
        print(f"  {abbr}: {count} picks")
    
    print("\n" + "=" * 70)

if __name__ == "__main__":
    print_database_stats()
    
    # Test some functions
    print("\n🧪 Testing database functions:")
    
    print("\n1. Get Lakers roster (first 3 players):")
    lal_roster = get_team_roster('LAL')
    for p in lal_roster[:3]:
        print(f"   {p['name']:20s} OVR:{p['ovr']:2d} ${p['salary']:5.1f}M")
    
    print("\n2. Find LeBron James:")
    lebron = get_player_by_name("LeBron James")
    if lebron:
        print(f"   Team: {lebron['team']}, OVR: {lebron['ovr']}, Salary: ${lebron['salary']}M")
    
    print("\n3. Lakers draft picks:")
    lal_picks = get_team_picks('LAL')
    print(f"   1st round: {', '.join(lal_picks['1st'][:5])}")
    
    print("\n✅ All tests passed!")
