#!/usr/bin/env python3
"""
NBA Trade Validation Engine v50.0
Zero-Hallucination Design: All rules validated programmatically
"""

import json
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

# ============================================================================
# CONSTANTS FROM OFFICIAL CBA (2024-25 Season)
# ============================================================================

SALARY_CAP = 140.588
LUXURY_TAX = 170.814
FIRST_APRON = 178.132
SECOND_APRON = 188.931
MIN_TEAM_SALARY = 126.529

class ApronStatus(Enum):
    UNDER_CAP = "under_cap"
    UNDER_TAX = "under_tax"
    FIRST_APRON = "first_apron"
    SECOND_APRON = "second_apron"

@dataclass
class Player:
    name: str
    team: str
    salary: float
    age: int
    position: str
    years_left: int
    trade_status: str = "available"  # available, recently_signed, recently_extended
    
@dataclass
class DraftPick:
    year: int
    round: int  # 1 or 2
    original_team: str
    current_owner: str
    protection: Optional[str] = None  # e.g., "top-4"

@dataclass
class Team:
    name: str
    salary: float
    roster: List[Player]
    picks: List[DraftPick]
    apron_status: ApronStatus

@dataclass
class TradeProposal:
    team_a: str
    team_a_out: List[Player]
    team_a_picks_out: List[DraftPick]
    
    team_b: str
    team_b_out: List[Player]
    team_b_picks_out: List[DraftPick]
    
    # Optional: 3-team trades
    team_c: Optional[str] = None
    team_c_out: Optional[List[Player]] = None
    team_c_picks_out: Optional[List[DraftPick]] = None

@dataclass
class ValidationResult:
    valid: bool
    confidence: float  # 0.0 to 1.0
    errors: List[str]
    warnings: List[str]
    calculations: Dict[str, any]

# ============================================================================
# SALARY MATCHING CALCULATOR
# ============================================================================

def calculate_max_incoming_salary(outgoing: float, apron_status: ApronStatus) -> float:
    """
    Official NBA salary matching formula
    
    Returns: Maximum salary that can be received
    """
    if apron_status == ApronStatus.SECOND_APRON:
        # Second apron teams: CANNOT take in more than they send out
        return outgoing
    
    if outgoing <= 6.5:
        # Can receive greater of: (outgoing + 5M) or (outgoing × 2)
        return max(outgoing + 5.0, outgoing * 2.0)
    elif outgoing <= 29.0:
        # Can receive: outgoing × 125% + $100k
        return outgoing * 1.25 + 0.1
    else:
        # Same formula for >$29M
        return outgoing * 1.25 + 0.1

def validate_salary_match(team_out: float, team_in: float, apron_status: ApronStatus) -> Tuple[bool, str]:
    """
    Validate if salary matching rules are satisfied
    
    Returns: (is_valid, explanation)
    """
    max_in = calculate_max_incoming_salary(team_out, apron_status)
    
    if team_in > max_in:
        return False, f"Salary mismatch: Sending ${team_out:.1f}M can only receive up to ${max_in:.1f}M (attempting ${team_in:.1f}M)"
    
    return True, f"Salary match OK: ${team_out:.1f}M out, ${team_in:.1f}M in (max: ${max_in:.1f}M)"

# ============================================================================
# STEPIEN RULE VALIDATOR
# ============================================================================

def check_stepien_rule(team_picks: List[DraftPick], pick_to_trade: DraftPick) -> Tuple[bool, str]:
    """
    Stepien Rule: Cannot trade away first-round picks in consecutive years
    
    Returns: (is_valid, explanation)
    """
    if pick_to_trade.round != 1:
        return True, "Stepien rule only applies to 1st round picks"
    
    year = pick_to_trade.year
    
    # Check if team owns picks for year-1 and year+1
    owns_prev_year = any(p.year == year - 1 and p.round == 1 for p in team_picks)
    owns_next_year = any(p.year == year + 1 and p.round == 1 for p in team_picks)
    
    if not owns_prev_year and not owns_next_year:
        return False, f"Stepien Rule violation: Trading {year} 1st without owning {year-1} or {year+1} 1st"
    
    return True, "Stepien Rule satisfied"

# ============================================================================
# APRON RESTRICTIONS CHECKER
# ============================================================================

def check_apron_restrictions(team: Team, trade: TradeProposal) -> Tuple[bool, List[str]]:
    """
    Check all apron-related restrictions
    
    Returns: (is_valid, list_of_violations)
    """
    violations = []
    
    if team.apron_status == ApronStatus.SECOND_APRON:
        # Count players being sent out
        if team.name == trade.team_a:
            players_out = trade.team_a_out
            players_in = trade.team_b_out
        else:
            players_out = trade.team_b_out
            players_in = trade.team_a_out
        
        # RULE: Cannot aggregate multiple players
        if len(players_out) > 1:
            violations.append("Second Apron teams cannot aggregate multiple players in trades")
        
        # RULE: Cannot take in more salary than sent out
        salary_out = sum(p.salary for p in players_out)
        salary_in = sum(p.salary for p in players_in)
        
        if salary_in > salary_out:
            violations.append(f"Second Apron teams cannot take in more salary than sent: ${salary_out:.1f}M out vs ${salary_in:.1f}M in")
    
    return len(violations) == 0, violations

# ============================================================================
# MAIN TRADE VALIDATOR
# ============================================================================

def validate_trade(trade: TradeProposal, teams: Dict[str, Team]) -> ValidationResult:
    """
    Main validation function - checks ALL rules
    
    Returns: Complete validation result
    """
    errors = []
    warnings = []
    calculations = {}
    
    # Get team objects
    team_a = teams[trade.team_a]
    team_b = teams[trade.team_b]
    
    # ========================================================================
    # CRITICAL CHECK 1: Player Ownership
    # ========================================================================
    for player in trade.team_a_out:
        if player.team != trade.team_a:
            errors.append(f"CRITICAL: {player.name} is not on {trade.team_a} (actually on {player.team})")
    
    for player in trade.team_b_out:
        if player.team != trade.team_b:
            errors.append(f"CRITICAL: {player.name} is not on {trade.team_b} (actually on {player.team})")
    
    # ========================================================================
    # CRITICAL CHECK 2: Pick Ownership
    # ========================================================================
    for pick in trade.team_a_picks_out:
        if pick.current_owner != trade.team_a:
            errors.append(f"CRITICAL: {trade.team_a} does not own {pick.year} round {pick.round} pick (owned by {pick.current_owner})")
    
    for pick in trade.team_b_picks_out:
        if pick.current_owner != trade.team_b:
            errors.append(f"CRITICAL: {trade.team_b} does not own {pick.year} round {pick.round} pick (owned by {pick.current_owner})")
    
    # ========================================================================
    # CRITICAL CHECK 3: Salary Matching
    # ========================================================================
    salary_a_out = sum(p.salary for p in trade.team_a_out)
    salary_a_in = sum(p.salary for p in trade.team_b_out)
    
    valid_a, msg_a = validate_salary_match(salary_a_out, salary_a_in, team_a.apron_status)
    calculations['team_a_salary'] = {
        'out': salary_a_out,
        'in': salary_a_in,
        'status': msg_a
    }
    
    if not valid_a:
        errors.append(f"SALARY MATCH FAILED for {trade.team_a}: {msg_a}")
    
    salary_b_out = sum(p.salary for p in trade.team_b_out)
    salary_b_in = sum(p.salary for p in trade.team_a_out)
    
    valid_b, msg_b = validate_salary_match(salary_b_out, salary_b_in, team_b.apron_status)
    calculations['team_b_salary'] = {
        'out': salary_b_out,
        'in': salary_b_in,
        'status': msg_b
    }
    
    if not valid_b:
        errors.append(f"SALARY MATCH FAILED for {trade.team_b}: {msg_b}")
    
    # ========================================================================
    # CRITICAL CHECK 4: Stepien Rule
    # ========================================================================
    for pick in trade.team_a_picks_out:
        if pick.round == 1:
            valid, msg = check_stepien_rule(team_a.picks, pick)
            if not valid:
                errors.append(f"STEPIEN VIOLATION for {trade.team_a}: {msg}")
    
    for pick in trade.team_b_picks_out:
        if pick.round == 1:
            valid, msg = check_stepien_rule(team_b.picks, pick)
            if not valid:
                errors.append(f"STEPIEN VIOLATION for {trade.team_b}: {msg}")
    
    # ========================================================================
    # IMPORTANT CHECK 5: Apron Restrictions
    # ========================================================================
    valid_apron_a, violations_a = check_apron_restrictions(team_a, trade)
    if not valid_apron_a:
        errors.extend([f"{trade.team_a}: {v}" for v in violations_a])
    
    valid_apron_b, violations_b = check_apron_restrictions(team_b, trade)
    if not valid_apron_b:
        errors.extend([f"{trade.team_b}: {v}" for v in violations_b])
    
    # ========================================================================
    # WARNING CHECK: Trade Status
    # ========================================================================
    for player in trade.team_a_out + trade.team_b_out:
        if player.trade_status == "recently_signed":
            warnings.append(f"{player.name} was recently signed and may have 3-month trade restriction")
        elif player.trade_status == "recently_extended":
            warnings.append(f"{player.name} was recently extended and may have 6-month trade restriction")
    
    # ========================================================================
    # Calculate Confidence
    # ========================================================================
    confidence = 1.0
    if len(errors) > 0:
        confidence = 0.0  # Critical errors = no confidence
    elif len(warnings) > 0:
        confidence = 0.95  # Warnings = slight reduction
    else:
        confidence = 0.995  # All clear = very high confidence
    
    # ========================================================================
    # Return Result
    # ========================================================================
    return ValidationResult(
        valid=len(errors) == 0,
        confidence=confidence,
        errors=errors,
        warnings=warnings,
        calculations=calculations
    )

# ============================================================================
# OUTPUT FORMATTER
# ============================================================================

def format_validation_output(result: ValidationResult) -> str:
    """
    Format validation result for display
    """
    output = []
    
    # Status Header
    if result.valid:
        output.append("✅ VALIDATION: PASSED")
    else:
        output.append("❌ VALIDATION: FAILED")
    
    # Confidence
    conf_pct = result.confidence * 100
    if conf_pct >= 99:
        conf_label = "HIGH"
    elif conf_pct >= 90:
        conf_label = "MEDIUM"
    else:
        conf_label = "LOW"
    
    output.append(f"📊 Confidence: {conf_label} ({conf_pct:.1f}%)")
    
    # Errors
    if result.errors:
        output.append("\n🚫 ERRORS:")
        for error in result.errors:
            output.append(f"  - {error}")
    
    # Warnings
    if result.warnings:
        output.append("\n⚠️  WARNINGS:")
        for warning in result.warnings:
            output.append(f"  - {warning}")
    
    # Calculations
    if result.calculations:
        output.append("\n🔍 CALCULATIONS:")
        for key, value in result.calculations.items():
            output.append(f"  {key}: {value}")
    
    return "\n".join(output)

# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    # Example: Lakers trying to trade D'Angelo Russell for Nic Claxton
    
    # Define players
    russell = Player("D'Angelo Russell", "LAL", 18.7, 28, "PG", 1)
    claxton = Player("Nic Claxton", "BKN", 28.0, 25, "C", 4)
    
    # Define teams
    lakers = Team(
        name="LAL",
        salary=188.3,
        roster=[russell],
        picks=[],
        apron_status=ApronStatus.SECOND_APRON
    )
    
    nets = Team(
        name="BKN",
        salary=170.5,
        roster=[claxton],
        picks=[],
        apron_status=ApronStatus.UNDER_TAX
    )
    
    # Create trade
    trade = TradeProposal(
        team_a="LAL",
        team_a_out=[russell],
        team_a_picks_out=[],
        team_b="BKN",
        team_b_out=[claxton],
        team_b_picks_out=[]
    )
    
    # Validate
    result = validate_trade(trade, {"LAL": lakers, "BKN": nets})
    
    # Print result
    print(format_validation_output(result))
